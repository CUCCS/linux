#无人值守安装ISO制作实验报告
##第一步 配置实验环境
###下载安装Ubuntu-16.04.1镜像
![Ubuntu-16.04.1](/Users/admin/Desktop/media/安装Ubuntu-16.04.1.jpeg)


##第二步 无人值守安装ISO制作
**1.在当前用户目录下创建一个用于挂载iso镜像文件的目录:**
`mkdir loopdir`

![mkdir loopdir](/Users/admin/Desktop/media/mkdir_loopdir.jpeg)


**2.挂载iso镜像文件到该目录:**
`mount -o loop ubuntu-16.04.1-server-amd64.iso loopdir`

![挂载iso](/Users/admin/Desktop/media/guazaiiso.jpeg
)

**3.创建一个工作目录用于克隆光盘内容:**

`mkdir cd`

![mkdir cd](/Users/admin/Desktop/media/mkdir cd.jpeg)


**4.同步光盘内容到目标工作目录**

**一定要注意loopdir后的这个/，cd后面不能有/:**
`rsync -av loopdir/ cd`

![rsync](/Users/admin/Desktop/media/rsync.jpeg)

**5.卸载iso镜像:**

`umount loopdir`

![umount](/Users/admin/Desktop/media/umount.jpeg)

**6.进入目标工作目录:**

`cd cd/`

![cd](/Users/admin/Desktop/media/cd.jpeg)

**7.编辑Ubuntu安装引导界面增加一个新菜单项入口:**
`vim isolinux/txt.cfg`

**8.添加以下内容到该文件后强制保存退出:**

```
label autoinstall
  menu label ^Auto Install Ubuntu Server
  kernel /install/vmlinuz
  append  file=/cdrom/preseed/ubuntu-server-autoinstall.seed debian-installer/locale=en_US console-setup/layoutcode=us keyboard-configuration/layoutcode=us console-setup/ask_detect=false localechooser/translation/warn-light=true localechooser/translation/warn-severe=true initrd=/install/initrd.gz root=/dev/ram rw quiet
```

![vim](/Users/admin/Desktop/media/vim.jpeg)

**9.提前阅读并编辑定制Ubuntu官方提供的示例preseed.cfg，并将该文件保存到刚才创建的工作目录:  ~/cd/preseed/ubuntu-server-autoinstall.seed**
![copyseed](/Users/admin/Desktop/media/seed.jpeg)

**10.修改isolinux/isolinux.cfg，增加内容timeout 10（可选，否则需要手动按下ENTER启动安装界面:**

![vimiso](/Users/admin/Desktop/media/vimiso.jpeg)

**11.从host登陆虚拟机并完成操作**

```
# 重新生成md5sum.txt
cd ~/cd && find . -type f -print0 | xargs -0 md5sum > md5sum.txt

# 封闭改动后的目录到.iso
IMAGE=custom.iso
BUILD=~/cd/

mkisofs -r -V "Custom Ubuntu Install CD" \
            -cache-inodes \
            -J -l -b isolinux/isolinux.bin \
            -c isolinux/boot.cat -no-emul-boot \
            -boot-load-size 4 -boot-info-table \
            -o $IMAGE $BUILD
# 如果目标磁盘之前有数据，则在安装过程中会在分区检测环节出现人机交互对话框需要人工选择
```

![login&build](/Users/admin/Desktop/media/login.jpeg)

**12.导出镜像**

![getcustom](/Users/admin/Desktop/media/getcustom.jpeg)

##下载Custom.iso
**新建虚拟机并下载**
![download](/Users/admin/Desktop/media/download.jpeg)

**安装完成**
![succeed](/Users/admin/Desktop/media/succeed.jpeg)
